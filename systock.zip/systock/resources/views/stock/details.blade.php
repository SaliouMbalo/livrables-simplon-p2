@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Détails du stock</div>
                <div class="card-body">
                <table class="table table-bordered table-striped">
                                <tbody>
                                    <tr>
                                        <th style="font-size:125%">
                                            N°
                                        </th>
                                        <td style="font-size:125%">
                                            {{ $stock->id }}
                                        </td>
                                    </tr>
                                    <tr >
                                        <th style="font-size:125%">
                                            Nom
                                        </th>
                                        <td style="font-size:125%">
                                            {{ $stock->nom }}
                                        </td>
                                    </tr>
                                    <tr>
                                        <th style="font-size:125%">
                                            Prix
                                        </th>
                                        <td style="font-size:125%">
                                            {{ $stock->prix }}
                                        </td>
                                    </tr>
                                    <tr>
                                        <th style="font-size:125%">
                                            Description
                                        </th>
                                        <td style="font-size:125%">
                                            {{ $stock->description }}
                                        </td>
                                    </tr>
                                    <tr>
                                        <th style="font-size:125%">
                                            Quantité
                                        </th>
                                        <td style="font-size:125%">
                                            {{ $stock->quantite }}
                                        </td>
                                    </tr>



                                </tbody>
                            </table>

                            <div class="form-group">
                                <a class="btn btn-danger" href="{{ route('getallstock') }}">
                                    Retour à la liste
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
