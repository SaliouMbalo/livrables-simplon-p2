@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Formulaire de modification de stock</div>
                <div class="card-body">
                    @if(isset($confirmation))
                       @if($confirmation == 1)
                       <div class="alert alert-success">Stock modifié avec succés!</div>
                       @else
                       <div class="alert alert-danger">Erreur modification!</div>
                       @endif
                    @endif
                    <form method="post" action="{{action('StockController@update', $stock->id )}}">
                        @csrf

                        <div class="form-group row">
                            <label for="id" class="col-md-4 col-form-label text-md-right">N° du stock</label>

                            <div class="col-md-6">
                                <input id="id" type="text" class="form-control" readonly="true" name="id" value="{{ $stock->id }}"  autofocus>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="nom" class="col-md-4 col-form-label text-md-right">Nom</label>

                            <div class="col-md-6">
                                <input id="nom" type="text" class="form-control" name="nom" value="{{ $stock->nom }}">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="prix" class="col-md-4 col-form-label text-md-right">Prix</label>

                            <div class="col-md-6">
                                <input id="prix" type="text" class="form-control" name="prix" value="{{ $stock->prix }}">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="description" class="col-md-4 col-form-label text-md-right">Description</label>

                            <div class="col-md-6">
                                <input id="description" type="text" class="form-control" name="description" value="{{ $stock->description }}">
                            </div>
                        </div>

                           <div class="form-group row">
                            <label for="quantite" class="col-md-4 col-form-label text-md-right">Quantité</label>

                            <div class="col-md-6">
                                <input id="quantite" type="text" class="form-control" name="quantite" value="{{ $stock->quantite }}">
                            </div>
                        </div>


                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <input id="enregistrer" type="submit" class="btn btn-success" name="enregistrer" required autocomplete="enregistrer" value="Enregistrer" autofocus onclick="return confirm('Voulez-vous vraiment modifier?')">
                                <a class="btn btn-danger" href="{{ route( 'getallstock' )}}">Annuler</a>

                        </div>


                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
