<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Détails du stock</div>
                <div class="card-body">
                <table class="table table-bordered table-striped">
                                <tbody>
                                    <tr>
                                        <th style="font-size:125%">
                                            N°
                                        </th>
                                        <td style="font-size:125%">
                                            <?php echo e($stock->id); ?>

                                        </td>
                                    </tr>
                                    <tr >
                                        <th style="font-size:125%">
                                            Nom
                                        </th>
                                        <td style="font-size:125%">
                                            <?php echo e($stock->nom); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <th style="font-size:125%">
                                            Prix
                                        </th>
                                        <td style="font-size:125%">
                                            <?php echo e($stock->prix); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <th style="font-size:125%">
                                            Description
                                        </th>
                                        <td style="font-size:125%">
                                            <?php echo e($stock->description); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <th style="font-size:125%">
                                            Quantité
                                        </th>
                                        <td style="font-size:125%">
                                            <?php echo e($stock->quantite); ?>

                                        </td>
                                    </tr>



                                </tbody>
                            </table>

                            <div class="form-group">
                                <a class="btn btn-danger" href="<?php echo e(route('getallstock')); ?>">
                                    Retour à la liste
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projet-laravel\systock\resources\views/stock/details.blade.php ENDPATH**/ ?>