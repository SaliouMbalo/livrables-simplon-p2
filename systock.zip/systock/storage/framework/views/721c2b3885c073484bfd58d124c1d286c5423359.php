<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Formulaire de modification de compte</div>
                <div class="card-body">
                    <?php if(isset($confirmation)): ?>
                       <?php if($confirmation == 1): ?>
                       <div class="alert alert-success">Compte modifié avec succés!</div>
                       <?php else: ?>
                       <div class="alert alert-danger">Erreur modification!</div>
                       <?php endif; ?>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('updatecompte')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="id" class="col-md-4 col-form-label text-md-right">Identifiant du compte</label>

                            <div class="col-md-6">
                                <input id="id" type="text" class="form-control" readonly="true" name="id" value="<?php echo e($compte->id); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="numero" class="col-md-4 col-form-label text-md-right">Numéro compte</label>

                            <div class="col-md-6">
                                <input id="numero" type="text" class="form-control" name="numero" value="<?php echo e($compte->numero); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="solde" class="col-md-4 col-form-label text-md-right">Solde</label>

                            <div class="col-md-6">
                                <input id="solde" type="text" class="form-control" name="solde" value="<?php echo e($compte->solde); ?>">
                            </div>
                        </div>

                    

                        <div class="form-group row">
                            <label for="user_id" class="col-md-4 col-form-label text-md-right">Utilisateur</label>

                            <div class="col-md-6">
                                <input id="user_id" type="text" class="form-control" name="user_id" readonly="true" value="<?php echo e($compte->user_id); ?>">
                            </div>
                        </div>


                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <input id="enregistrer" type="submit" class="btn btn-success" name="enregistrer" value="Enregistrer">
                                <a class="btn btn-danger" href="<?php echo e(route( 'getallcompte' )); ?>">Annuler</a>

                        </div>

                       
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projet-laravel\bdp\resources\views/compte/edit.blade.php ENDPATH**/ ?>