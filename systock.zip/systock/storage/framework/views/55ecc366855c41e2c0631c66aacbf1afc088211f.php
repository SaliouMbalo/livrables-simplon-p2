<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Liste des Notes de Frais</div>
                <div class="card-body">
                <table class="table table-bordered table-striped">
                    <tr class="table-primary">
                        <th scope="row">ID</th> 
                        <th scope="row">Matricule</th> 
                        <th scope="row">Prénoms</th> 
                        <th scope="row">Nom</th> 
                        <th scope="row">Objet de mission</th> 
                        <th scope="row">Zone de mission</th> 
                        <th scope="row">Lieu de mission</th>
                        <th scope="row">Action</th> 
                    </tr>  
                    <?php $__currentLoopData = $liste_note_de_frais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note_de_frais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($note_de_frais->id); ?></td> 
                        <td><?php echo e($note_de_frais->matricule); ?></td> 
                        <td><?php echo e($note_de_frais->prenoms); ?></td> 
                        <td><?php echo e($note_de_frais->nom); ?></td>  
                        <td><?php echo e($note_de_frais->objet); ?></td> 
                        <td><?php echo e($note_de_frais->zone_mission); ?></td> 
                        <td><?php echo e($note_de_frais->lieu_de_mission); ?></td> 
                        <td><a href="<?php echo e(route('editnote_de_frais', ['id'=>$note_de_frais->id])); ?>">Editer</a></td>
                        <td class="btn btn-danger"><a href="<?php echo e(route('deletenote_de_frais', ['id'=>$note_de_frais->id])); ?>" onclick="return confirm('Voulez-vous confirmez la suppression ?')">Archiver</a></td>
                    </tr>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </table>   

                <?php echo e($liste_note_de_frais->links()); ?>



                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-master\bdp\resources\views/notedefrais/liste.blade.php ENDPATH**/ ?>