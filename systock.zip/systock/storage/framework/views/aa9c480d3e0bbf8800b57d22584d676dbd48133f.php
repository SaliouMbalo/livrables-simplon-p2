<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Formulaire d'ajout de stock</div>
                <div class="card-body">
                    <?php if(isset($confirmation)): ?>
                       <?php if($confirmation == 1): ?>
                       <div class="alert alert-success">Stock ajouté avec succés!</div>
                       <?php else: ?>
                       <div class="alert alert-danger">Erreur ajout!</div>
                       <?php endif; ?>
                    <?php endif; ?>
                    <form method="POST" action="/stock/persist">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="nom" class="col-md-4 col-form-label text-md-right">Nom</label>

                            <div class="col-md-6">
                                <input id="nom" type="text" class="form-control" name="nom" required autocomplete="name" autofocus>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="prix" class="col-md-4 col-form-label text-md-right">Prix</label>

                            <div class="col-md-6">
                                <input id="prix" type="text" class="form-control" name="prix" required autocomplete="prix" autofocus>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="description" class="col-md-4 col-form-label text-md-right">Description</label>

                            <div class="col-md-6">
                                <input id="description" type="text" class="form-control" name="description"  required autocomplete="description" autofocus>
                            </div>
                        </div>

                           <div class="form-group row">
                            <label for="quantite" class="col-md-4 col-form-label text-md-right">Quantité</label>

                            <div class="col-md-6">
                                <input id="quantite" type="text" class="form-control" name="quantite" required autocomplete="quantite" autofocus>
                            </div>
                        </div>


                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <input id="enregistrer" type="submit" class="btn btn-success" name="enregistrer" value="Enregistrer">
                                <input id="annuler" type="reset" class="btn btn-danger" name="annuler" value="Annuler">
                        </div>


                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projet-laravel\systock\resources\views/stock/add.blade.php ENDPATH**/ ?>