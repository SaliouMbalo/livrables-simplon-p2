<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Liste des produits</div>
                <div class="card-body">
                <table class="table table-bordered table-striped">
                    <tr class="table-primary" style="text-align: center" >
                        <th scope="row">N°</th>
                        <th scope="row">Nom</th>
                        <th scope="row">Prix</th>
                        <th scope="row">Description</th>
                        <th scope="row">Quantité</th>
                        <th colspan="3" scope="row">Edition</th>

                    </tr>
                    
                    <?php $__currentLoopData = $liste_stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($stock->id); ?></td>
                        <td><?php echo e($stock->nom); ?></td>
                        <td><?php echo e($stock->prix); ?></td>
                        <td><?php echo e($stock->description); ?></td>
                        <td><?php echo e($stock->quantite); ?></td>
                        <td><a class="btn-sm btn-success" href="<?php echo e(route('showstock', ['id'=>$stock->id])); ?>">Afficher</a></td>
                        <td><a class="btn-sm btn-warning" href="<?php echo e(route('editstock', ['id'=>$stock->id])); ?>">Modifier</a></td>
                        <td><a class="btn-sm btn-danger" href="<?php echo e(route('deletestock', ['id'=>$stock->id])); ?>" onclick="return confirm('Voulez-vous confirmez la suppression ?')">Supprimer</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </table>

                
                <?php echo e($liste_stocks->links()); ?>



                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projet-laravel\systock\resources\views/stock/liste.blade.php ENDPATH**/ ?>