<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Formulaire d'ajout de compte</div>

                <div class="card-body">
                    <?php if(isset($confirmation)): ?>
                       <?php if($confirmation == 1): ?>
                       <div class="alert alert-success">Compte ajouté avec succés!</div>
                       <?php else: ?>
                       <div class="alert alert-danger">Erreur ajout!</div>
                       <?php endif; ?>
                    <?php endif; ?>
                    <form method="POST" action="/compte/persist">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="numero" class="col-md-4 col-form-label text-md-right">Numéro</label>

                            <div class="col-md-6">
                                <input id="numero" type="text" class="form-control" name="numero" required autocomplete="numero" autofocus>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="solde" class="col-md-4 col-form-label text-md-right">Solde</label>

                            <div class="col-md-6">
                                <input id="solde" type="text" class="form-control" name="solde" required autocomplete="solde" autofocus>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="clients_id" class="col-md-4 col-form-label text-md-right">Choisissez un client</label>

                            <div class="col-md-6">
                                <select id="clients_id" class="form-control" name="clients_id" required>
                                    <option value="0">Faites un choix</option>
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($client->id); ?>" required><?php echo e($client->prenom); ?> <?php echo e($client->nom); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </div>
                        </div>

                         <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <input id="enregistrer" type="submit" class="btn btn-success" name="enregistrer"  value="Enregistrer">
                                <input id="annuler" type="reset" class="btn btn-danger" name="annuler" value="Annuler">
                        </div>


                       
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projet-laravel\bdp\resources\views/compte/add.blade.php ENDPATH**/ ?>