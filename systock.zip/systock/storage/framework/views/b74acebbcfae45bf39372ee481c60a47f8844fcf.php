<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Formulaire de modification de stock</div>
                <div class="card-body">
                    <?php if(isset($confirmation)): ?>
                       <?php if($confirmation == 1): ?>
                       <div class="alert alert-success">Stock modifié avec succés!</div>
                       <?php else: ?>
                       <div class="alert alert-danger">Erreur modification!</div>
                       <?php endif; ?>
                    <?php endif; ?>
                    <form method="post" action="<?php echo e(action('StockController@update', $stock->id )); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="id" class="col-md-4 col-form-label text-md-right">N° du stock</label>

                            <div class="col-md-6">
                                <input id="id" type="text" class="form-control" readonly="true" name="id" value="<?php echo e($stock->id); ?>"  autofocus>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="nom" class="col-md-4 col-form-label text-md-right">Nom</label>

                            <div class="col-md-6">
                                <input id="nom" type="text" class="form-control" name="nom" value="<?php echo e($stock->nom); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="prix" class="col-md-4 col-form-label text-md-right">Prix</label>

                            <div class="col-md-6">
                                <input id="prix" type="text" class="form-control" name="prix" value="<?php echo e($stock->prix); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="description" class="col-md-4 col-form-label text-md-right">Description</label>

                            <div class="col-md-6">
                                <input id="description" type="text" class="form-control" name="description" value="<?php echo e($stock->description); ?>">
                            </div>
                        </div>

                           <div class="form-group row">
                            <label for="quantite" class="col-md-4 col-form-label text-md-right">Quantité</label>

                            <div class="col-md-6">
                                <input id="quantite" type="text" class="form-control" name="quantite" value="<?php echo e($stock->quantite); ?>">
                            </div>
                        </div>


                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <input id="enregistrer" type="submit" class="btn btn-success" name="enregistrer" required autocomplete="enregistrer" value="Enregistrer" autofocus onclick="return confirm('Voulez-vous vraiment modifier?')">
                                <a class="btn btn-danger" href="<?php echo e(route( 'getallstock' )); ?>">Annuler</a>

                        </div>


                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projet-laravel\systock\resources\views/stock/edit.blade.php ENDPATH**/ ?>