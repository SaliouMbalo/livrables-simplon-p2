<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Liste des comptes</div>
                <div class="card-body">
                <table class="table table-bordered table-striped">
                    <tr class="table-primary">
                        <th>Identifiant</th> 
                        <th>Numéro compte</th> 
                        <th>Solde compte</th> 
                        <th>Client</th> 
                        <th>Utilisateur</th> 
                        <th>Action</th>
                        <th>Action</th> 
                    </tr>  
                    <?php $__currentLoopData = $liste_comptes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($compte->id); ?></td> 
                        <td><?php echo e($compte->numero); ?></td>  
                        <td><?php echo e($compte->solde); ?></td>  
                        <td><?php echo e($compte->clients_id); ?></td>  
                        <td><?php echo e($compte-> user_id); ?></td> 
                        <td><a href="<?php echo e(route('editcompte', ['id'=>$compte->id])); ?>">Editer</a></td>
                        <td><a href="<?php echo e(route('deletecompte', ['id'=>$compte->id])); ?>">Archiver</a></td>
                    </tr>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </table>    
                <?php echo e($liste_comptes->links()); ?>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-master\bdp\resources\views/compte/liste.blade.php ENDPATH**/ ?>