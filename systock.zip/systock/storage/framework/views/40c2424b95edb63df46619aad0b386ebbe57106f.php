<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Liste des clients</div>
                <div class="card-body">
                <table class="table table-bordered table-striped">
                    <tr class="table-primary">
                        <th scope="row">Identifiant</th> 
                        <th scope="row">Prénoms</th> 
                        <th scope="row">Nom</th> 
                        <th scope="row">Adresse</th> 
                        <th scope="row">Téléphone</th> 
                        <th scope="row">Action</th>
                        <th scope="row">Action</th> 
                    </tr>  
                    <?php $__currentLoopData = $liste_clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($client->id); ?></td> 
                        <td><?php echo e($client->prenom); ?></td> 
                        <td><?php echo e($client->nom); ?></td>  
                        <td><?php echo e($client->adresse); ?></td> 
                        <td><?php echo e($client->telephone); ?></td> 
                        <td><a href="<?php echo e(route('editclient', ['id'=>$client->id])); ?>">Editer</a></td>
                        <td class="btn btn-danger"><a href="<?php echo e(route('deleteclient', ['id'=>$client->id])); ?>" onclick="return confirm('Voulez-vous confirmez la suppression ?')">Archiver</a></td>
                    </tr>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </table>   

                <?php echo e($liste_clients->links()); ?>



                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-master\bdp\resources\views/client/liste.blade.php ENDPATH**/ ?>