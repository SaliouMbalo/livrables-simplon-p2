<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Stock extends Model
{
     protected $fillable = array('nom', 'prix', 'description', 'quantite');
    public static $rules = array('nom'=>'required|min:3',
								 'prix'=>'required|min:3',
								 'description'=>'required|min:3',
								 'quantite'=>'required|min:3'
								);

}
