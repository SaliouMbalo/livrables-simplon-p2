<?php

namespace App\Http\Controllers;

use App\Stock;
use Illuminate\Http\Request;

class StockController extends Controller
{
     public function __construct()
    {
        $this->middleware('auth');
    }

    public function add ()

    {
    	return view('stock.add');

    }

    public function getAll ()

    {
        //pour la pagination de la liste des stocks
        $liste_stocks = Stock::paginate(5);

        //$liste_stocks = Stock::all();
    	return view('stock.liste', ['liste_stocks'=>$liste_stocks]);

    }

    public function edit ($id)

    {
        $stock = Stock::find($id);
    	return view('stock.edit', ['stock' => $stock]);

    }

    public function update (Request $request)

    {
        $stock = Stock::find($request->id);
        $stock->nom = $request->nom;
        $stock->prix = $request->prix;
        $stock->description = $request->description;
        $stock->quantite = $request->quantite;

        $stock->save();

        $result = $stock->save();//1 ou 0

    	return redirect ('/stock/getAll');

    }

    public function delete ($id)

    {
        $stock = Stock::find($id);
        if( $stock != null)
        {
            $stock->delete();
        }
    	return redirect ('/stock/getAll');

    }

    public function show($id)

    {
        $stock = Stock::find($id);
    	return view('stock.details', ['stock' => $stock]);
    }

    public function persist (Request $request)

    {
        $stock = new Stock();
        $stock->nom = $request->nom;
        $stock->prix = $request->prix;
        $stock->description = $request->description;
        $stock->quantite = $request->quantite;

        $stock->save();

        $result = $stock->save();//1 ou 0

        return view( 'stock.add', ['confirmation'=>$result]);

    }
}
