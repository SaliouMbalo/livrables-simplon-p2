<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index');

Route::get('/stock/add', 'StockController@add')->name('addstock');
Route::get('/stock/edit/{id}', 'StockController@edit')->name('editstock');
Route::post('/stock/update', 'StockController@update')->name('updatestock');
Route::get('/stock/delete/{id}', 'StockController@delete')->name('deletestock');
Route::get('/stock/getAll', 'StockController@getAll')->name('getallstock');
Route::post('/stock/persist', 'StockController@persist')->name('persiststock');
Route::get('/stock/show/{id}', 'StockController@show')->name('showstock');
